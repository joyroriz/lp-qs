function Header() {
  try {
    return (
      <header className="glass-card fixed top-0 left-0 right-0 z-40 mx-4 mt-4 rounded-2xl" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <div className="icon-zap text-white text-xl"></div>
              </div>
              <span className="text-2xl font-bold gradient-text">Qualify Sales</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#revolucao" className="text-white hover:text-cyan-400 transition-colors font-medium">
                Revolução
              </a>
              <a href="#como-funciona" className="text-white hover:text-cyan-400 transition-colors font-medium">
                Como Funciona
              </a>
              <a href="#casos-sucesso" className="text-white hover:text-cyan-400 transition-colors font-medium">
                Casos de Sucesso
              </a>
              <button className="btn-primary text-sm">
                Experimente Grátis
              </button>
            </nav>
            
            <div className="md:hidden">
              <div className="icon-menu text-xl text-white"></div>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}