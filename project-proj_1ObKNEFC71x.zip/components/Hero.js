function Hero() {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    setIsVisible(true);
  }, []);

  try {
    return (
      <section className="animated-bg min-h-screen relative overflow-hidden flex items-center" data-name="hero" data-file="components/Hero.js">
        {/* Animated Particles Background */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white bg-opacity-20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className={`space-y-8 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
              <div className="space-y-4">
                <div className="inline-flex items-center space-x-2 bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-4 py-2 text-white">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium">REVOLUÇÃO ODONTOLÓGICA 2025</span>
                </div>
                
                <h1 className="text-6xl lg:text-7xl font-bold text-white leading-tight">
                  A Nova Era da
                  <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-white">
                    Odontologia
                  </span>
                </h1>
                
                <p className="text-2xl text-blue-100 font-light leading-relaxed">
                  Inteligência Artificial que Converte 
                  <span className="font-bold text-cyan-400"> Sorrisos em Resultados</span>
                </p>
              </div>
              
              <p className="text-xl text-blue-100 leading-relaxed">
                Revolucione sua clínica odontológica com chamadas automatizadas por IA que 
                reduzem absenteísmo, aumentam agendamentos e convertem pacientes em tempo real.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="btn-primary text-lg px-10 py-5 pulse-glow">
                  <div className="icon-rocket text-xl mr-3"></div>
                  Experimente Gratuitamente
                </button>
                <button className="btn-secondary text-lg px-10 py-5">
                  <div className="icon-play-circle text-xl mr-3"></div>
                  Ver Demonstração
                </button>
              </div>
              
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <div className="icon-shield-check text-cyan-400 text-xl"></div>
                  <span className="text-sm text-blue-100">Implementação em 24h</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="icon-trending-up text-cyan-400 text-xl"></div>
                  <span className="text-sm text-blue-100">ROI garantido em 30 dias</span>
                </div>
              </div>
            </div>
            
            <div className={`relative transition-all duration-1000 delay-500 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
              <div className="relative floating">
                <div className="glass-card p-8 transform rotate-3">
                  <img 
                    src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                    alt="Clínica odontológica moderna com IA" 
                    className="w-full rounded-xl shadow-2xl"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-cyan-400 to-blue-500 text-white p-4 rounded-xl shadow-xl">
                    <div className="text-2xl font-bold">+347%</div>
                    <div className="text-sm">Conversão Média</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}